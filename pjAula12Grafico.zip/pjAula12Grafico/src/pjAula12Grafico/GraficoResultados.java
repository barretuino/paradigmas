package pjAula12Grafico;

import javax.swing.JFrame;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

public class GraficoResultados extends JFrame {

	//Construir a minha Frame
	public GraficoResultados(String chartTitle ) {
		setTitle("Gr�fico de Resultados");
		
		//Instanciando o meu Gr�fico
		/**
		 * chartTitle - T�tulo do Gr�fico
		 * eixo X - Texto
		 * eixo Y - Texto
		 * createDataset - S�o os valores
		 * sentido da plotagem
		 * exige legenda?
		 * tooltips
		 * ativa urls
		 */
		JFreeChart lineChart = ChartFactory.createBarChart(chartTitle,
				"Sala","N�mero de Alunos",
				createDataset(),
				PlotOrientation.VERTICAL,
				true,true,false);
					
		ChartPanel chartPanel = new ChartPanel( lineChart );
		chartPanel.setPreferredSize( new java.awt.Dimension( 560 , 367 ) );
		setContentPane( chartPanel );
	}

	private DefaultCategoryDataset createDataset( ) {
		DefaultCategoryDataset dataset = new DefaultCategoryDataset( );
		dataset.addValue( 15 , "sala" , "SL1" );
		dataset.addValue( 30 , "sala" , "SL2" );
		dataset.addValue( 45 , "sala" ,  "SL2" );
		dataset.addValue( 17 , "sala" , "SL3" );
		dataset.addValue( 10 , "sala" , "SL4" );
		dataset.addValue( 31 , "sala" , "SL5" );
		dataset.addValue( 22 , "corredor" , "SL1" );
		dataset.addValue( 40 , "corredor" , "SL2" );
		dataset.addValue( 17 , "corredor" , "SL3" );
		dataset.addValue( 11 , "bloco" , "SL1" );
		dataset.addValue( 13 , "bloco" , "SL2" );
		dataset.addValue( 23 , "bloco" , "SL3" );
				
		return dataset;
	}

	public static void main( String[ ] args ) {
		GraficoResultados chart = new GraficoResultados("N�mero de Alunos por Sala");

		chart.pack( );
		//RefineryUtilities.centerFrameOnScreen( chart );
		chart.setVisible( true );
	}
}